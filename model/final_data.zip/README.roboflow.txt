
hackathon1 - v11 2021-04-18 4:05am
==============================

This dataset was exported via roboflow.ai on April 18, 2021 at 8:06 AM GMT

It includes 80 images.
A are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)

The following augmentation was applied to create 3 versions of each source image:


